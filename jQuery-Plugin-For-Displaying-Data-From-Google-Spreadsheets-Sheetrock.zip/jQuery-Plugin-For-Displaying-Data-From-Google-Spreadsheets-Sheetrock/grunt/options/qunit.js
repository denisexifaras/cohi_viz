/* grunt-contrib-qunit */

module.exports = {
  app: ['test/*.html']
};
